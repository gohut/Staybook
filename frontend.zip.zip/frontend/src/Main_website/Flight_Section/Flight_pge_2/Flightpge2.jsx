import BookingTopNavbar from "./BookingTopNavbar";
import BookingLayout from "./BookingLayout";
import TopNavbar from "../../Top_Navbar/TopNavbar";

export default function Flightpge2() {
  return (
    <>
      <TopNavbar/>
      
      <BookingLayout />
    </>
  );
}